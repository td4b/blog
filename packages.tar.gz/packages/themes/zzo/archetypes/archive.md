---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
type: archive
description:
titleWrap: wrap # wrap, noWrap
---
