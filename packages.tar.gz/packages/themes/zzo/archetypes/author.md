---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
description:
tags:
-
series:
-
categories:
-
author:
authorEmoji: 🤖
authorImage: "/images/whoami/avatar.jpg"
authorImageUrl: ""
authorDesc: 
socialOptions:
  email: ""
  phone: ""
  facebook: ""
  twitter: ""
  github: ""
  stack-overflow: ""
  instagram: ""
  google-plus: ""
  youtube: ""
  medium: ""
  tumblr: ""
  linkedin: ""
  pinterest: ""
  stack-exchange: ""
  telegram: ""
  steam: ""
  weibo: ""
  douban: ""
  csdn: ""
  gitlab: ""
  mastodon: ""
  jianshu: ""
  zhihu: ""
  signal: ""
  whatsapp: ""
  matrix: ""
  xmpp: ""
  dev-to: ""
  gitea: ""
  google-scholar: ""
  twitch: ""
---
