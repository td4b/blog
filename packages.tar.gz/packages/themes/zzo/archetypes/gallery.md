---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
description: 
type: gallery
mode: at-once # at-once or one-by-one
tags:
-
series:
-
categories:
-
images: # when mode is one-by-one, images front matter works
  - image: 
    caption: 
---
