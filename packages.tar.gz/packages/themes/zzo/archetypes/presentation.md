---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
description: 
type: presentation
tags:
-
series:
-
categories:
-
plugins:
- highlight
- zoom
- notes
- math
highlightTheme: monokai # monokai, zenburn
revealTheme: beige # beige, black, blood, league, monokai, moon, night, serif, simple, sky, solarized, white
revealBackgroundColor: "" # #fff or rgba() or hsl()
revealBackgroundImage: "" # /images/myImage.png   <= static folder path
revealBackgroundPosition: "" # left top, left center, left bottom, right top, right center ...
revealBackgroundRepeat: "" # repeat, repeat-x, repeat-y, no-repeat, inherit
revealBackgroundOpacity: "" # 0~1
revealBackgroundVideo: "" # /videos/myVideo.mp4 <= static folder path, A single video source, or a comma separated list of video sources.
revealBackgroundVideoLoop: false # true, false
revealBackgroundVideoMuted: false # true, false
revealBackgroundSize: "" # cover, contain, ...
reveal: 
  - main:
    - sub: 
      - | 

    - sub: 
      - | 
      
  - main:
    - sub: 
      - |
      
---
