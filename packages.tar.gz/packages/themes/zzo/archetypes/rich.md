---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
description:
tags:
-
series:
-
categories:
-
libraries:
- katex 
- mathjax
- chart
- flowchartjs
- msc
- katex
- mermaid
- viz
- wavedrom
---
