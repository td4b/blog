---
title: "Hugo zDoc Theme"
date: 2020-01-19T21:13:42+09:00
description: Make a documentation with hugo zdoc theme!
weight: 2
link: https://github.com/zzossig/hugo-theme-zdoc
repo: https://github.com/zzossig/hugo-theme-zdoc
pinned: true
thumb: feature3/css3-bare.png
---
