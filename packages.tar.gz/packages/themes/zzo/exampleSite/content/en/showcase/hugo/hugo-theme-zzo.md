---
title: "Hugo Zzo Theme"
date: 2020-01-19T21:13:42+09:00
description: Make a blog with hugo zzo theme!
weight: 1
link: https://github.com/zzossig/hugo-theme-zzo
repo: https://github.com/zzossig/hugo-theme-zzo
pinned: true
thumb: feature3/css3.png
---
